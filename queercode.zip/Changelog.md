0.5.5-alpha: generate `emoji-map` from GUI; define asset filepath. known filepath handling issues across multiple components resulting in negative behavioral impact.
0.5.0-alpha: plugin is now more modular, with logic split into 5 main files (`main.ts`, `SettingsTab.ts`, `MapHandler.ts`, `EmojiService.ts`, and `EmojiSuggest.ts`) plus `emoji-map.json`.
0.4.6-alpha: in `suggest.ts`, replacement now detects closing `:` and correctly replaces existing shortcode
0.4.5-alpha: adjusted regex in main.ts and suggest.ts; suggestions should appear when `:` is preceded by MD formatting characters; TreeWalker now appropriately handles node siblings disrupted by `<br>`. suggester and callouts now work as expected
0.4.0-alpha: fixed (most) nested span rendering and injection; autocomplete in tables now functions (and renders) as expected
0.3.0-alpha: added suggestion + autocomplete (EditorSuggest class, fuzzysort)
0.2.5-alpha: add .svg support
0.2.0-alpha: cleanup file structure and plugin logic, smarter and less destructive emoji-map generation
0.1.0-alpha: initial commit; DOM injection for basic nodes
